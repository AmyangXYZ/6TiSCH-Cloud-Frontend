<template>
  <div id="app">
    <Navbar/>
    <Sidebar/>
    <keep-alive>
      <router-view/>
    </keep-alive>
  </div>
</template>

<script>
import Navbar from './layout/Navbar'
import Sidebar from './layout/Sidebar'

export default {
  name: 'app',
  components: {
    Navbar,
    Sidebar,
  },
}

</script>

<style>
html, body {
  height: 100%;
  width: 100%;
  margin: 0;
  padding: 0;
  background-color: #EBECF1;
  font-size: 1.2rem;
}

#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
  margin-top: 90px;
}
</style>
