<template>
  <vs-row vs-align="flex-start" vs-w="12">
    <vs-col style="z-index:99" vs-offset="0.8" vs-w="4.2">
      <Status/>
      <SensorTable/>
    </vs-col>
    <vs-col style="z-index:99" vs-offset="0.3" vs-w="6">
      <Map/>
    </vs-col>
  </vs-row> 
</template>>

<script>
import Status from '../components/dashboard/Status'
import SensorTable from '../components/dashboard/SensorTable'
import Map from '../components/dashboard/Map'

// window.console.log(Status.getGateway())

export default {
    components: {
      Status,
      SensorTable,
      Map,
    },
}
</script>