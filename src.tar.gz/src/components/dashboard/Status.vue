<template>
<vs-card>
    <div slot="header">
    <h3>
        Server Status
    </h3>
    </div>
    <div>
        {{gateway}}
    </div>
</vs-card>
</template>

<script>

export default {
    data() {
        return {
            gateway: "",
        }
    },
    methods: {    
        getGateway() {
            this.$api.gateway.getGateway()
            .then(res=> {
                 this.gateway = res.data.data[0]
            })    
        }  
    },
    mounted: function () {
        this.getGateway();
    }
}
</script>