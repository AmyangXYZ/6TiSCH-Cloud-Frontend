<template>
  <vs-card > 
    <GmapMap id="gmap" :center="center" :zoom="zoom">
      <GmapMarker :key="m.sensor_id" v-for="m in markers" :position="{lat:m.gps_lat,lng:m.gps_lon}"  
        :clickable="true" @click="center=m.position" />
      <!-- <GmapPolyline  v-for="line in lines"
        :key="line.id"
        :path="line.path">
      </GmapPolyline> -->
    </GmapMap>
  </vs-card>
</template>

<script>
export default {
  data () {
    return {
      zoom: 20,
      center: {lat:41.806581, lng:-72.252763}, // ITEB
      markers: [
      ],
    }
  },
  methods: {
    getTopology() {
      this.$api.gateway.getTopology("UCONN_GW")
      .then(res=> {
        this.markers = res.data.data
      })
    }
  },
  mounted: function () {
    this.getTopology();
  }
}
</script>

<style lang="stylus" scoped>
#gmap
    width 100%
    height 500px
</style>