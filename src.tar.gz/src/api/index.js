import gateway from '@/api/gateway'

export default {
    gateway,
}